<!--
  Stephanie Lara
  April 26, 2026
  Module 7 Programming Assignment
  
  Purpose: Validate submitted form data and display the results or error messages. 
  -->

<!DOCTYPE html>
<html>
  <head>
    <title>Stephanie Pet Adoption Response</title>
  </head>

  <body>
    <center>

    <?php

      $errors = array();

      $fullName = trim($_POST["fullName"]);
      $email = trim($_POST["email"]);
      $petCount = trim($_POST["petCount"]);
      $preferredPet = $_POST["preferredPet"];
      $adoptionReason = trim($_POST["adoptionReason"]);

      if($fullName == ""){
        $errors[] = "Full Name is required.";
      }

      if($email == ""){
        $errors[] = "Email Address is required.";
      }
      elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $errors[] = "Email Address must be entered correctly.";
      }

      if($petCount == ""){
        $errors[] = "Number of Pets Currently Owned is required.";
      }
      elseif(!is_numeric($petCount) || $petCount < 0){
        $errors[] = "Number of Pets Currently Owned must be zero or higher.";
      }

      if($preferredPet == ""){
        $errors[] = "Preferred Pet must be selected.";
      }

      if(empty($_POST["experience"])){
        $errors[] = "Experience With Pets must be selected.";
      }
      else{
        $experience = $_POST["experience"];
      }

      if(empty($_POST["supplies"])){
        $errors[] = "At least one supply must be selected.";
      }
      else{
        $supplies = $_POST["supplies"];
      }

      if($adoptionReason == ""){
        $errors[] = "Reason for adopting a pet is required.";
      }

      if(!empty($errors)){

        print("<h1>Form Error</h1>");
        print("<p>Please correct the following problems:</p>");

        print("<ul>");
        foreach($errors as $error){
          print("<li>$error</li>");
        }
        print("</ul>");

        print("<p><a href='StephanieForm.html'>Return to Form</a></p>");

      }
      else{

        print("<h1>Pet Adoption Interest Summary</h1>");

        print("<table border='1' cellpadding='8'>");

        print("<tr>");
        print("<td><strong>Full Name</strong></td>");
        print("<td>$fullName</td>");
        print("</tr>");

        print("<tr>");
        print("<td><strong>Email Address</strong></td>");
        print("<td>$email</td>");
        print("</tr>");

        print("<tr>");
        print("<td><strong>Number of Pets Currently Owned</strong></td>");
        print("<td>$petCount</td>");
        print("</tr>");

        print("<tr>");
        print("<td><strong>Preferred Pet</strong></td>");
        print("<td>$preferredPet</td>");
        print("</tr>");

        print("<tr>");
        print("<td><strong>Experience With Pets</strong></td>");
        print("<td>$experience</td>");
        print("</tr>");

        print("<tr>");
        print("<td><strong>Supplies You Already Have</strong></td>");
        print("<td>");

        foreach($supplies as $supply){
          print("$supply<br />");
        }

        print("</td>");
        print("</tr>");

        print("<tr>");
        print("<td><strong>Reason for Adopting</strong></td>");
        print("<td>$adoptionReason</td>");
        print("</tr>");

        print("</table>");
      }

    ?>

    </center>
  </body>
</html>