<!DOCTYPE html>
<html lang='en'>
    <!--
      Stephanie Lara
      March 27, 2026
      Module 1.3 Programming Assignment

      Purpose: To demonstrate basic PHP functionality
     -->
    <head>
        <title>Module 1.3 Programming Assignment</title>
    </head>

    <body>
        <!-- First PHP Code -->
        <?php 
        
        echo "Hello. PHP is working. <br /><br />"; 
        
        ?>
        
        <!-- Second PHP Code-->
        <?php

        echo("What is the sum of 25 and 25? <br />");

        $num1 = 25;
        $num2 = 25;

        $sum = $num1 + $num2;

        echo("Answer: $sum");

        ?>

    </body>
</html>