<!-- Stephanie Lara
    April 18, 2026
    Module 5.2 Programming Assignment

    Purpose: Create 10 customers with (first name, last name, age, phone number) and display records based on different criteria.
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Customer Records</title>
</head>
<body>

<?php

// Array of 10 customers (first name, last name, age, phone number)
$customers = [
    ["first" => "Stephanie", "last" => "Lara", "age" => 36, "phone" => "714-458-0344"],
    ["first" => "Jesus", "last" => "Gonzales", "age" => 35, "phone" => "714-818-5461"],
    ["first" => "Yecenia", "last" => "Orozco", "age" => 33, "phone" => "714-548-9656"],
    ["first" => "Jonathan", "last" => "Ramos", "age" => 31, "phone" => "714-312-6217"],
    ["first" => "Martha", "last" => "Cerda", "age" => 63, "phone" => "562-881-9745"],
    ["first" => "Jackie", "last" => "Machuca", "age" => 40, "phone" => "909-465-8216"],
    ["first" => "Nathan", "last" => "Jones", "age" => 54, "phone" => "310-465-8165"],
    ["first" => "Matthew", "last" => "Marquez", "age" => 32, "phone" => "310-626-6325"],
    ["first" => "Destiny", "last" => "Nolasco", "age" => 30, "phone" => "562-691-8456"],
    ["first" => "Ulises", "last" => "Martinez", "age" => 33, "phone" => "714-906-7177"]
];

// Display all customers
echo "<h2>All Customers</h2>";
foreach ($customers as $customer) {
    echo $customer["first"] . " " . $customer["last"] . ", age " . $customer["age"] . ", " . $customer["phone"] . "<br>";
}

// Display records based on different criteria

echo "<h2>Customers in their 30s</h2>";
foreach ($customers as $customer) {
    if ($customer["age"] >= 30 && $customer["age"] <= 39) {
        echo $customer["first"] . " " . $customer["last"] . ", age " . $customer["age"] . ", " . $customer["phone"] . "<br>";
    }
}

echo "<h2>Customers 40 and older</h2>";
foreach ($customers as $customer) {
    if ($customer["age"] > 39) {
        echo $customer["first"] . " " . $customer["last"] . ", age " . $customer["age"] . ", " . $customer["phone"] . "<br>";
    }
}

echo "<h2>Customers with 714 area code</h2>";
foreach ($customers as $customer) {
    if (substr($customer["phone"], 0, 3) == "714") {
        echo $customer["first"] . " " . $customer["last"] . ", age " . $customer["age"] . ", " . $customer["phone"] . "<br>";
    }
}

echo "<h2>Customers whose first name starts with J</h2>";
foreach ($customers as $customer) {
    if (substr($customer["first"], 0, 1) == "J") {
        echo $customer["first"] . " " . $customer["last"] . ", age " . $customer["age"] . ", " . $customer["phone"] . "<br>";
    }
}

?>

</body>
</html>