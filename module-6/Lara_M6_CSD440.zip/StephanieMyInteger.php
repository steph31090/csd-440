<!--Stephanie Lara
    April 19, 2026
    Module 6 Programming Assignment

    Purpose: This program defines a class to represent inventory counts in a backroom. 
    It includes methods to check if the count is even, odd, or prime, and demonstrates the use of getters and setters.
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Backroom Inventory Checker</title>
</head>
<body>

<?php

class StephanieMyInteger {

    private $itemCount;

    function __construct($itemCount) {
        $this->itemCount = $itemCount;
    }

    function isEven($num) {
        return $num % 2 == 0;
    }

    function isOdd($num) {
        return $num % 2 != 0;
    }

    function isPrime() {
        if ($this->itemCount <= 1) {
            return false;
        }

        for ($i = 2; $i < $this->itemCount; $i++) {
            if ($this->itemCount % $i == 0) {
                return false;
            }
        }
        return true;
    }

    function getItemCount() {
        return $this->itemCount;
    }

    function setItemCount($newCount) {
        $this->itemCount = $newCount;
    }
}

// Create two locations
$locationA = new StephanieMyInteger(12);
$locationB = new StephanieMyInteger(7);

// Location A
echo "<h3>Location A</h3>";
echo "Items: " . $locationA->getItemCount() . "<br>";
echo "Even: " . ($locationA->isEven($locationA->getItemCount()) ? "Yes" : "No") . "<br>";
echo "Odd: " . ($locationA->isOdd($locationA->getItemCount()) ? "Yes" : "No") . "<br>";
echo "Prime: " . ($locationA->isPrime() ? "Yes" : "No") . "<br><br>";

// Location B
echo "<h3>Location B</h3>";
echo "Items: " . $locationB->getItemCount() . "<br>";
echo "Even: " . ($locationB->isEven($locationB->getItemCount()) ? "Yes" : "No") . "<br>";
echo "Odd: " . ($locationB->isOdd($locationB->getItemCount()) ? "Yes" : "No") . "<br>";
echo "Prime: " . ($locationB->isPrime() ? "Yes" : "No") . "<br><br>";

// Test Setter
echo "<h3>Updating Location A</h3>";
$locationA->setItemCount(15);
echo "New item count: " . $locationA->getItemCount();

?>

</body>
</html>