<?php

/*
    Name: Stephanie Lara
    May 23, 2026
    Module 11 Programming Assignment

    Purpose: Connects to the baseball_01 database
             and displays the data in a PDF table.
*/

# FPDF library
require('./fpdf.php');

# Database connection information
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "baseball_01";

# Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

# Check connection
if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);

}

# SQL query
$sql = "SELECT product_id, product_name, brand, category, price, rating, in_stock FROM targetbeauty";

$result = $conn->query($sql);

# Create PDF
$pdf = new FPDF();

# Landscape page
$pdf->AddPage('L');

# Title
$pdf->SetFont('Arial','B',16);
$pdf->SetTextColor(0,0,0);

$pdf->Cell(0,10,'Target Beauty Product Database Report',0,1,'C');

$pdf->ln(5);

# General information
$pdf->SetFont('Arial','',12);
$pdf->SetTextColor(0,0,0);

$pdf->MultiCell(
    0,
    8,
    'This report displays information collected from the Target Beauty database. This database contains information on makeup products including product names, brands, categories, prices, ratings, and stock availability.'
);

$pdf->ln(8);

# Table header
$pdf->SetFont('Arial','B',10);

$pdf->SetTextColor(255,255,255);

$pdf->SetFillColor(255,153,153);

$pdf->SetX(35);

$pdf->Cell(20,10,'ID',1,0,'C',true);
$pdf->Cell(55,10,'Product',1,0,'C',true);
$pdf->Cell(45,10,'Brand',1,0,'C',true);
$pdf->Cell(35,10,'Category',1,0,'C',true);
$pdf->Cell(20,10,'Price',1,0,'C',true);
$pdf->Cell(18,10,'Rating',1,0,'C',true);
$pdf->Cell(22,10,'Stock',1,1,'C',true);

# Table rows
$pdf->SetFont('Arial','',10);

$pdf->SetTextColor(0,0,0);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {

        $pdf->SetX(35);

        $pdf->Cell(20,10,$row["product_id"],1);

        $pdf->Cell(55,10,$row["product_name"],1);

        $pdf->Cell(45,10,$row["brand"],1);

        $pdf->Cell(35,10,$row["category"],1);

        $pdf->Cell(20,10,'$'.$row["price"],1);

        $pdf->Cell(18,10,$row["rating"],1);

        $pdf->Cell(22,10,$row["in_stock"],1);

        $pdf->ln();

    }

} else {

    $pdf->Cell(
        215,
        10,
        'No records found.',
        1,
        1,
        'C'
    );

}

# Footer row
$pdf->SetFont('Arial','B',10);

$pdf->SetTextColor(255,255,255);

$pdf->SetFillColor(255,153,153);

$pdf->SetX(35);

$pdf->Cell(
    215,
    10,
    'End of Makeup Product Report',
    1,
    1,
    'C',
    true
);

# Close connection
$conn->close();

# Output PDF
$pdf->Output();

?>