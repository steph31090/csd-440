<!--
  Name: Stephanie Lara
  May 23, 2026
  Module 11 Programming Assignment

  Purpose: This page opens the PDF report.
-->

<!DOCTYPE html>
<html lang='en'>

<head>

    <script>

        function getPDF(){

            window.open("StephaniePDF.php");

        }

    </script>

    <title>Stephanie PDF Program</title>
    <meta charset='utf-8'>

</head>

<body>

    <h1>Module 11 Database PDF Report</h1>

    <p>
        This button will generate a report for the Target Beauty database. The report will be displayed in a PDF document and will include 
        information on makeup products such as product names, brands, categories, prices, ratings, and stock availability. 
    
    </p>

    <button onclick="getPDF();" target="_blank">
        Generate PDF Report
    </button>

</body>

</html>