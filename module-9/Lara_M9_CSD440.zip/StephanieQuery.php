<!--
  Stephanie Lara
  May 10, 2026
  Module 9 Assignment

  Purpose:This page allows the user to search the targetbeauty table by category.
-->

<!DOCTYPE html>
<html>
  <head>
    <title>Stephanie Query.php</title>
  </head>

  <body>
    <center>
      <h1>Search Beauty Products</h1>

      <?php
        $conn = new mysqli("localhost", "student1", "pass", "baseball_01");

        if ($conn->connect_error) {
          die("ERROR: Unable to connect: " . $conn->connect_error);
        }

        $sql = "SELECT DISTINCT category FROM targetbeauty";

        $rs = mysqli_query($conn, $sql);

        if (!$rs) {
          exit("Error in SQL");
        }
      ?>

      <form action="StephanieQuery.php" method="post">
        <p>
          <label>
            Select a Product Category
            <br />
            <br />
          </label>

          <select name="category">
            <?php
              if (mysqli_num_rows($rs) > 0) {
                while($row = mysqli_fetch_assoc($rs)) {
                  echo('<option value="' . $row['category'] . '">' . $row['category'] . '</option>');
                }
              }
            ?>
          </select>
        </p>

        <p>
          <input type="submit" name="submit" value="Submit" />
        </p>
      </form>

      <?php
        if (isset($_POST["submit"])) {
          $category = $_POST["category"];

          $sql = 'SELECT * FROM targetbeauty WHERE category = "' . $category . '"';

          $rs = mysqli_query($conn, $sql);

          if (!$rs) {
            exit("Error in SQL");
          }
      ?>

      <h2>Product Results</h2>

      <table border="1" width="90%">
        <tr align="center" style="background-color:#ffffff;">
          <td><b>Product ID</b></td>
          <td><b>Product Name</b></td>
          <td><b>Brand</b></td>
          <td><b>Category</b></td>
          <td><b>Price</b></td>
          <td><b>Rating</b></td>
          <td><b>In Stock</b></td>
        </tr>

        <?php
          if (mysqli_num_rows($rs) > 0) {
            while($row = mysqli_fetch_assoc($rs)) {
        ?>

        <tr align="center" style="background-color:#ffffff;">
          <td><?php echo($row["product_id"]); ?></td>
          <td><?php echo($row["product_name"]); ?></td>
          <td><?php echo($row["brand"]); ?></td>
          <td><?php echo($row["category"]); ?></td>
          <td><?php echo($row["price"]); ?></td>
          <td><?php echo($row["rating"]); ?></td>
          <td><?php echo($row["in_stock"]); ?></td>
        </tr>

        <?php
            }
          }
          else {
            echo("<tr><td colspan='7'>No records found</td></tr>");
          }
        ?>

      </table>

      <?php
        }

        $conn->close();
      ?>

      <br />
      <br />

      <a href="StephanieIndex.php">Home</a>
    </center>
  </body>
</html>