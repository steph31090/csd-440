<!--
  Stephanie Lara
  May 10, 2026
  Module 9 Assignment

  Purpose: This page allows the user to add a new record to the targetbeauty table.
-->

<!DOCTYPE html>
<html>
  <head>
    <title>Stephanie Form.php</title>
  </head>

  <body>
    <center>
      <h1>Add a Beauty Product</h1>

      <form action="StephanieForm.php" method="post">
        <p>
          Product Name:
          <br />
          <input type="text" name="product_name" required />
        </p>

        <p>
          Brand:
          <br />
          <input type="text" name="brand" required />
        </p>

        <p>
          Category:
          <br />
          <input type="text" name="category" required />
        </p>

        <p>
          Price:
          <br />
          <input type="text" name="price" required />
        </p>

        <p>
          Rating:
          <br />
          <input type="text" name="rating" />
        </p>

        <p>
          In Stock:
          <br />
          <input type="text" name="in_stock" />
        </p>

        <p>
          <input type="submit" name="submit" value="Add Product" />
        </p>
      </form>

      <?php
        if (isset($_POST["submit"])) {
          $conn = new mysqli("localhost", "student1", "pass", "baseball_01");

          if ($conn->connect_error) {
            die("ERROR: Unable to connect: " . $conn->connect_error);
          }

          $product_name = $_POST["product_name"];
          $brand = $_POST["brand"];
          $category = $_POST["category"];
          $price = $_POST["price"];
          $rating = $_POST["rating"];
          $in_stock = $_POST["in_stock"];

          $sql = "INSERT INTO targetbeauty
                  (product_name, brand, category, price, rating, in_stock)
                  VALUES
                  ('$product_name', '$brand', '$category', '$price', '$rating', '$in_stock')";

          $rs = mysqli_query($conn, $sql);

          if (!$rs) {
            exit("Error in SQL");
          }
          else {
            echo("<p>Record added successfully.</p>");
          }

          $conn->close();
        }
      ?>

      <br />

      <a href="StephanieIndex.php">Home</a>
    </center>
  </body>
</html>