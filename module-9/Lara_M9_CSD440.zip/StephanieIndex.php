<!--
  Stephanie Lara
  May 10, 2026
  Module 9 Assignment
  
  Purpose: This page is the index page and provides links to the query page and form page.
-->

<!DOCTYPE html>
<html>
  <head>
    <title>Stephanie Index.php</title>
  </head>

  <body>
    <center>
      <h1>Target Beauty Product Inventory</h1>

      <p>
        This page provides links to search beauty products and add new products
        to the database.
      </p>

      <br />

      <a href="StephanieQuery.php">Search Beauty Products</a>

      <br />
      <br />

      <a href="StephanieForm.php">Add a Beauty Product</a>
    </center>
  </body>
</html>