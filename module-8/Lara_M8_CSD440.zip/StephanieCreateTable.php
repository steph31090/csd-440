<!-- Stephanie Lara
    May 3, 2026
    Module 8 Programming Assignment

    Purpose: To create the TargetBeauty table in the database.
    -->
<html>
<body>


<?php

$lineBreak = "<br />";

// Connect to database
$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

// Check connection
if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
}

echo "Connected to the database." . $lineBreak;

// Create table
$sql = "CREATE TABLE TargetBeauty (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(50) NOT NULL,
    brand VARCHAR(50) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(6,2) NOT NULL,
    rating DECIMAL(2,1),
    in_stock VARCHAR(10)
)";

// Execute query
if ($conn->query($sql) === TRUE) {
    echo "Table TargetBeauty created successfully." . $lineBreak;
} else {
    echo "Error creating table: " . $conn->error . $lineBreak;
}

$conn->close();

?>


</body>
</html>