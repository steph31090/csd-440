<!-- Stephanie Lara
    May 3, 2026
    Module 8 Programming Assignment

    Purpose: To delete TargetBeauty table from the database.
    -->

<html>
<body>


<?php

$lineBreak = "<br />";

// Connect to database
$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

// Check connection
if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
}

echo "Connected to the database." . $lineBreak;

// Drop table
$sql = "DROP TABLE TargetBeauty";

// Execute query
if ($conn->query($sql) === TRUE) {
    echo "Table TargetBeauty dropped successfully." . $lineBreak;
} else {
    echo "Error dropping table: " . $conn->error . $lineBreak;
}

$conn->close();

?>


</body>
</html>