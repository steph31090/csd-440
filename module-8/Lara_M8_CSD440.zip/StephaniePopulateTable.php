<!-- Stephanie Lara
    May 3, 2026
    Module 8 Programming Assignment

    Purpose: To insert sample beauty products data into the the TargetBeauty table.
    -->

<html>
<body>

<?php

$lineBreak = "<br />";

// Connect to database
$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

// Check connection
if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
}

echo "Products Added:" . $lineBreak;

// Insert records
mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Fit Me Foundation', 'Maybelline', 'Foundation', 8.99, 4.5, 'Yes')");
echo "Maybelline Fit Me Foundation added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Butter Bronzer', 'Physicians Formula', 'Bronzer', 15.99, 4.8, 'Yes')");
echo "Physicians Formula Butter Bronzer added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Lash Princess Mascara', 'Essence', 'Mascara', 4.99, 4.6, 'Yes')");
echo "Essence Lash Princess Mascara added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Photo Focus Foundation', 'Wet n Wild', 'Foundation', 6.99, 4.4, 'No')");
echo "Wet n Wild Photo Focus Foundation added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Baked Blush', 'Milani', 'Blush', 9.99, 4.8, 'Yes')");
echo "Milani Baked Blush added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Infallible Foundation', 'L’Oreal', 'Foundation', 14.99, 4.5, 'Yes')");
echo "L’Oreal Infallible Foundation added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Butter Gloss', 'NYX', 'Lip Gloss', 5.99, 4.7, 'Yes')");
echo "NYX Butter Gloss added" . $lineBreak;

mysqli_query($conn, "INSERT INTO TargetBeauty (product_name, brand, category, price, rating, in_stock)
VALUES ('Hydrating Camo Concealer', 'e.l.f.', 'Concealer', 7.00, 4.5, 'Yes')");
echo "e.l.f. Hydrating Camo Concealer added" . $lineBreak;

$conn->close();

?>


</body>
</html>