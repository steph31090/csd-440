<!-- Stephanie Lara
    May 3, 2026
    Module 8 Programming Assignment

    Purpose: To retrieve and display the data from the TargetBeauty table.
    -->

<html>
<body>

<?php

$lineBreak = "<br />";

// Connect to database
$conn = new mysqli("localhost", "student1", "pass", "baseball_01");

// Check connection
if ($conn->connect_error) {
    die("ERROR: Unable to connect: " . $conn->connect_error);
}

// Select all records from the table
$sql = "SELECT * FROM TargetBeauty";

$rs = mysqli_query($conn, $sql);

if (!$rs) {
    exit("Error in SQL");
}

?>

<h2>Target Beauty Products</h2>

<table border='1' width='90%'>
<tr align='center'>
    <td><b>Product ID</b></td>
    <td><b>Product Name</b></td>
    <td><b>Brand</b></td>
    <td><b>Category</b></td>
    <td><b>Price</b></td>
    <td><b>Rating</b></td>
    <td><b>In Stock</b></td>
</tr>

<?php

if (mysqli_num_rows($rs) > 0) {

    while($row = mysqli_fetch_assoc($rs)) {

?>

<tr align='center'>
    <td><?php echo($row["product_id"]); ?></td>
    <td><?php echo($row["product_name"]); ?></td>
    <td><?php echo($row["brand"]); ?></td>
    <td><?php echo($row["category"]); ?></td>
    <td><?php echo("$" . $row["price"]); ?></td>
    <td><?php echo($row["rating"]); ?></td>
    <td><?php echo($row["in_stock"]); ?></td>
</tr>

<?php

    }

} else {
    echo "No records found.";
}

$conn->close();

?>

</table>

</body>
</html>