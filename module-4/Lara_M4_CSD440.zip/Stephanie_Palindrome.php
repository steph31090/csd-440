<!--
        Stephanie Lara
        April 9, 2026
        Palindrome Assignment

        Purpose:
        This program checks if a string is a palindrome
        by comparing it to its reversed version.
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Palindrome Program</title>
</head>
<body>

<?php

    // Function to check if string is a palindrome
    function checkPalindrome($text) {
        $reverse = strrev($text);

        if ($text === $reverse) {
            return "Palindrome";
        } else {
            return "Not a Palindrome";
        }
    }

    // Array with six examples (3 palindromes and 3 not palindromes)
    $words = array(
        "stephanie", 
        "mom", 
        "tacoma", 
        "hannah", 
        "target", 
        "589985"
    );

    echo "<h1>Module 4.2 Assignment: Palindromes</h1>";


    echo "<p>Palindromes are words or numbers that read the same when reversed.</p>";
    echo "<p>Are these palindromes?</p>";

    $count = 1;

    foreach ($words as $word) {
        $reverseWord = strrev($word);
        $result = checkPalindrome($word);

        echo "<p>";
        echo $count . ". " . $word . "<br>";
        echo "Reversed: " . $reverseWord . "<br>";
        echo $result;
        echo "</p>";

        $count++;
    }
?>

</body>
</html>