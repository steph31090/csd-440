<!--
  Stephanie Lara
  May 14, 2026
  Module 10 Programming Assignment

  Purpose: To collect beauty product data from a form, validates
            the data, encodes the submitted values, and
            displays the result in JSON format.
  -->

<!DOCTYPE html>
<html lang='en'>

  <head>

    <title> Stephanie JSON </title>
    <meta charset='utf-8'>

    <style>
      body {
        font-family: Trebuchet MS
        margin: 30px; 
      }

      label {
        display: inline-block;
        width: 140px;
        margin-bottom: 10px;
      }

      input, select {
        width: 240px;
        padding: 5px;
        margin-bottom: 10px;
      }

      input[type='submit'] {
        width: auto;
        margin-left: 144px;
        padding: 5px 10px;
      }

      .displayBox {
        border: 1px solid #666666;
        background-color: #f4f4f4;
        padding: 15px;
        width: 520px;
        margin-top: 20px;
      }

      .errorBox {
        border: 1px solid #990000;
        background-color: #ffecec;
        color: #990000;
        padding: 15px;
        width: 520px;
        margin-top: 20px;
      }

      pre {
        white-space: pre-wrap;
      }
    </style>

  </head>

  <body>

    <h1>Beauty Product Form</h1>

    <?php

      # Create variables
      $newLine = '<br />';
      $errorMessage = '';

      # Check if the form has been submitted
      if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        # Store values in an array
        $productData = array(
          'Product Name' => trim($_POST['productName'] ?? ''),
          'Brand' => trim($_POST['brand'] ?? ''),
          'UPC Code' => trim($_POST['upcCode'] ?? ''),
          'Color' => trim($_POST['color'] ?? ''),
          'Price' => trim($_POST['price'] ?? ''),
          'Quantity' => trim($_POST['quantity'] ?? ''),
          'Product Type' => trim($_POST['productType'] ?? ''),
          'Finish' => trim($_POST['finish'] ?? '')
        );

        # Validation
        foreach($productData as $key => $value) {

          if ($value == '') {

            $errorMessage = 'Error: Please complete all fields before submitting the form.';
          }
        }

        if ($errorMessage == '' && (!is_numeric($productData['Price']) || $productData['Price'] < 0)) {

          $errorMessage = 'Error: Price must be a number and cannot be negative.';
        }

        if ($errorMessage == '') {

        
          $jsonData = json_encode($productData, JSON_PRETTY_PRINT);

          echo "<div class='displayBox'>";
          echo '<h2>JSON Output</h2>';
          echo '<pre>' . htmlspecialchars($jsonData) . '</pre>';
          echo '</div>';
          echo($newLine);

        } else {

          # If error is found, display error message
          echo "<div class='errorBox'>";
          echo '<h2>Error Display</h2>';
          echo $errorMessage;
          echo '</div>';
          echo($newLine);
        }
      }

    ?>

    <form method='post' action=''>

      <label for='productName'>Product Name:</label>
      <input type='text' name='productName' id='productName'>
      <br>

      <label for='brand'>Brand:</label>
      <input type='text' name='brand' id='brand'>
      <br>

      <label for='upcCode'>UPC Code:</label>
      <input type='text' name='upcCode' id='upcCode'>
      <br>

      <label for='color'>Color:</label>
      <input type='text' name='color' id='color'>
      <br>

      <label for='price'>Price:</label>
      <input type='text' name='price' id='price'>
      <br>

      <label for='quantity'>Quantity:</label>
      <input type='number' name='quantity' id='quantity'>
      <br>

      <label for='productType'>Product Type:</label>
      <select name='productType' id='productType'>
        <option value=''>Select One</option>
        <option value='Lipstick'>Lipstick</option>
        <option value='Foundation'>Foundation</option>
        <option value='Mascara'>Mascara</option>
        <option value='Blush'>Blush</option>
        <option value='Highlighter'>Highlighter</option>
        <option value='Cleanser'>Cleanser</option>
        <option value='Moisturizer'>Moisturizer</option>
      </select>
      <br>

      <label for='finish'>Finish:</label>
      <select name='finish' id='finish'>
        <option value=''>Select One</option>
        <option value='Matte'>Matte</option>
        <option value='Glossy'>Glossy</option>
        <option value='Dewy'>Dewy</option>
        <option value='Satin'>Satin</option>
        <option value='Shimmer'>Shimmer</option>
        <option value='Metallic'>Metallic</option>
      </select>
      <br>

      <input type='submit' value='Submit Form'>

    </form>

  </body>

</html>
